Andromeda Initiative Logo by Illusive Design on Deviantart
https://illusive-design.deviantart.com/art/Andromeda-Initiative-Tempest-Logo-644366502

Mass Effect: Andromeda logos and designs etc copyright EA/Bioware
http://www.masseffect.com

Second hand, heart and battery icons taken from clock skins bundled with ClockSkinMaker

Runner icon taken from clock skin by Gabriele “Gabolander” Zappi
https://plus.google.com/+GabrieleZappi/posts/VtcceYyhh97
